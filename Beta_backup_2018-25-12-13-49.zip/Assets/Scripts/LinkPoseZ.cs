﻿using UnityEngine;
using System.Collections;

public class LinkPoseZ : MonoBehaviour {

	public GameObject GamePose1, GamePose2;
	public Vector3 position2, position1;
    public Vector3 pos_tempZ;
	Vector3  size_temp;


	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		pos_tempZ = transform.position;
		size_temp = transform.localScale;
        position1 = GamePose1.GetComponent<Pose> ().pos;
		position2 = GamePose2.GetComponent<Pose2> ().pos2;

        float distanceZ = position2.z-position1.z;
		size_temp.z = distanceZ/2;
        pos_tempZ = position2;
        transform.position = pos_tempZ;
		transform.localScale = size_temp;
 }


}
