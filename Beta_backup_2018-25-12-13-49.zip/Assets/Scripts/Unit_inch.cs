﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Unit_inch : MonoBehaviour {

    public Distance_text dis_txt;
    public Pose marker1;
    public Pose2 marker2;
    public Unit_m m_unit;
    public float posX_INCH, posY_INCH, posZ_INCH;
    public float pos2X_INCH, pos2Y_INCH, pos2Z_INCH;
    float CM_INCH = 2.54f, M_INCH = 39.37f, FOOT_INCH = 12;
    public Text INCH_text;
    
    float change_inch;

    public GameObject showUnitINCH;

    // Use this for initialization
    void Start()
    {
        showUnitINCH.SetActive(false);
        INCH_text.gameObject.SetActive(false);
        m_unit.Unit_txt.gameObject.SetActive(false);
        m_unit.showUnitM.gameObject.SetActive(false);
        
    }

    // Update is called once per frame
    void Update()
    {
        INCH_text.text = "DisInInch:" + change_inch.ToString();
        INCH_calculation();
        change_inch = GameObject.Find("distance_text").GetComponent<Distance_text>().total_Distance / CM_INCH;
    }



    public void show_inch()
    {
        INCH_text.gameObject.SetActive(true);
        showUnitINCH.SetActive(true);
        dis_txt.distance.gameObject.SetActive(false);
        m_unit.Unit_txt.gameObject.SetActive(false);
        m_unit.showUnitM.gameObject.SetActive(false);

    }



    public void INCH_calculation()
    {
        if (marker1.unit == 0)
        {
            posX_INCH = marker1.pos.x;
            posY_INCH = marker1.pos.y;
            posZ_INCH = marker1.pos.z;

            pos2X_INCH = marker2.pos2.x;
            pos2Y_INCH = marker2.pos2.y;
            pos2Z_INCH = marker2.pos2.z;

        }
        else if (marker1.unit == 3)
        {
            posX_INCH = marker1.pos.x / CM_INCH;
            posY_INCH = marker1.pos.y / CM_INCH;
            posZ_INCH = marker1.pos.z / CM_INCH;
            marker1.pos1_x.text = "CM_to_INCH X:" + posX_INCH.ToString();
            marker1.pos1_y.text = "CM_to_INCH Y:" + posY_INCH.ToString();
            marker1.pos1_z.text = "CM_to_INCH Z:" + posZ_INCH.ToString();

            pos2X_INCH = marker2.pos2.x / CM_INCH;
            pos2Y_INCH = marker2.pos2.y / CM_INCH;
            pos2Z_INCH = marker2.pos2.z / CM_INCH;
            marker2.pos2_x.text = "CM_to_INCH X:" + pos2X_INCH.ToString();
            marker2.pos2_y.text = "CM_to_INCH Y:" + pos2Y_INCH.ToString();
            marker2.pos2_z.text = "CM_to_INCH Z:" + pos2Z_INCH.ToString();
           
        }
        else if (marker1.unit == 4)
        {
            posX_INCH = marker1.pos.x * M_INCH;
            posY_INCH = marker1.pos.y * M_INCH;
            posZ_INCH = marker1.pos.z * M_INCH;
            marker1.pos1_x.text = "M_to_INCH X:" + posX_INCH.ToString();
            marker1.pos1_y.text = "M_to_INCH Y:" + posY_INCH.ToString();
            marker1.pos1_z.text = "M_to_INCH Z:" + posZ_INCH.ToString();

            pos2X_INCH = marker2.pos2.x * M_INCH;
            pos2Y_INCH = marker2.pos2.y * M_INCH;
            pos2Z_INCH = marker2.pos2.z * M_INCH;
            marker2.pos2_x.text = "M_to_INCH X:" + pos2X_INCH.ToString();
            marker2.pos2_y.text = "M_to_INCH Y:" + pos2Y_INCH.ToString();
            marker2.pos2_z.text = "M_to_INCH Z:" + pos2Z_INCH.ToString();
            
        }
    }

    public void OnClickButton_INCH()
    {
        if (m_unit.check == 0 || m_unit.check == 5 || m_unit.check == 6)
        {

            m_unit.check = 3;

            GameObject.Find("Cube").GetComponent<Pose>().unit = m_unit.check;
            GameObject.Find("Sphere").GetComponent<Pose2>().unit2 = m_unit.check;

        }
        else if (m_unit.check == 1 || m_unit.check == 2)
        {
            m_unit.check = 4;

            GameObject.Find("Cube").GetComponent<Pose>().unit = m_unit.check;
            GameObject.Find("Sphere").GetComponent<Pose2>().unit2 = m_unit.check;
        }
    }
}
