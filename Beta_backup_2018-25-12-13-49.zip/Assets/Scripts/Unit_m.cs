﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Unit_m : MonoBehaviour
{
    public Distance_text dis_txt;
    public Pose marker1;
    public Pose2 marker2;
    public float posX, posY, posZ;
    public float pos2X, pos2Y, pos2Z;
    float _M = 100, _INCH = 2.54f, _FOOT = 30.48f;
    public Text Unit_txt;
    public int check;

    float change_unit;
    
    public GameObject showUnitM;

    void Start()
    {
        showUnitM.SetActive(false);
        Unit_txt.gameObject.SetActive(false);
        
        check = marker1.unit;

    }

    void Update()
    {
        
        unit_calculation();
        
    }

    public void show_meter()
    {
        Unit_txt.gameObject.SetActive(true);
        showUnitM.SetActive(true);
        dis_txt.distance.gameObject.SetActive(false);
       

    }

    public void unit_calculation()
    {
        if (marker1.unit == 0)
        {
            posX = marker1.pos.x;
            posY = marker1.pos.y;
            posZ = marker1.pos.z;

            pos2X = marker2.pos2.x;
            pos2Y = marker2.pos2.y;
            pos2Z = marker2.pos2.z;

        }
        else if (marker1.unit == 1 )
        {
            posX = marker1.pos.x / _M;
            posY = marker1.pos.y / _M;
            posZ = marker1.pos.z / _M;
            marker1.pos1_x.text = "M1 X:" + posX.ToString();
            marker1.pos1_y.text = "M1 Y:" + posY.ToString();
            marker1.pos1_z.text = "M1 Z:" + posZ.ToString();

            pos2X = marker2.pos2.x / _M;
            pos2Y = marker2.pos2.y / _M;
            pos2Z = marker2.pos2.z / _M;
            marker2.pos2_x.text = "M 2X:" + pos2X.ToString();
            marker2.pos2_y.text = "M 2Y:" + pos2Y.ToString();
            marker2.pos2_z.text = "M 2Z:" + pos2Z.ToString();

            Unit_txt.text = "DisInM:" + change_unit.ToString();
            change_unit = GameObject.Find("distance_text").GetComponent<Distance_text>().total_Distance / _M;

        }
        else if (marker1.unit == 2 )
        {
            posX = marker1.pos.x / _INCH;
            posY = marker1.pos.y / _INCH;
            posZ = marker1.pos.z / _INCH;
            marker1.pos1_x.text = "INCH 1X:" + posX.ToString();
            marker1.pos1_y.text = "INCH 1Y:" + posY.ToString();
            marker1.pos1_z.text = "INCH 1Z:" + posZ.ToString();

            pos2X = marker2.pos2.x / _INCH;
            pos2Y = marker2.pos2.y / _INCH;
            pos2Z = marker2.pos2.z / _INCH;
            marker2.pos2_x.text = "INCH 2X:" + pos2X.ToString();
            marker2.pos2_y.text = "INCH 2Y:" + pos2Y.ToString();
            marker2.pos2_z.text = "INCH 2Z:" + pos2Z.ToString();

            Unit_txt.text = "DisInInch:" + change_unit.ToString();
            change_unit = GameObject.Find("distance_text").GetComponent<Distance_text>().total_Distance / _INCH;
        }
        else if (marker1.unit == 3)
        {
            posX = marker1.pos.x / _FOOT;
            posY = marker1.pos.y / _FOOT;
            posZ = marker1.pos.z / _FOOT;
            marker1.pos1_x.text = "FOOT 1X:" + posX.ToString();
            marker1.pos1_y.text = "FOOT 1Y:" + posY.ToString();
            marker1.pos1_z.text = "FOOT 1Z:" + posZ.ToString();

            pos2X = marker2.pos2.x / _FOOT;
            pos2Y = marker2.pos2.y / _FOOT;
            pos2Z = marker2.pos2.z / _FOOT;
            marker2.pos2_x.text = "FOOT 2X:" + pos2X.ToString();
            marker2.pos2_y.text = "FOOT 2Y:" + pos2Y.ToString();
            marker2.pos2_z.text = "FOOT 2Z:" + pos2Z.ToString();

            Unit_txt.text = "DisInFoot:" + change_unit.ToString();
            change_unit = GameObject.Find("distance_text").GetComponent<Distance_text>().total_Distance / _FOOT;
        }
    }



    public void change_to_m()
    {
        check = 1;
            
        GameObject.Find("Cube").GetComponent<Pose>().unit = check;
        GameObject.Find("Sphere").GetComponent<Pose2>().unit2 = check;
    }

    public void change_to_inch()
    {
        check = 2;

        GameObject.Find("Cube").GetComponent<Pose>().unit = check;
        GameObject.Find("Sphere").GetComponent<Pose2>().unit2 = check;
    }

    public void change_to_foot()
    {
        check = 3;

        GameObject.Find("Cube").GetComponent<Pose>().unit = check;
        GameObject.Find("Sphere").GetComponent<Pose2>().unit2 = check;
    }

    public void change_to_cm()
    {
        check = 0;

        GameObject.Find("Cube").GetComponent<Pose>().unit = check;
        GameObject.Find("Sphere").GetComponent<Pose2>().unit2 = check;
    }
}
