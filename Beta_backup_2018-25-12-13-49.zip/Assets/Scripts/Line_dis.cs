﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Line_dis : MonoBehaviour {

    private LineRenderer line_render;
    public Transform Cube;
    public Transform Sphere;
    public float length_line;


	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        line_render = GetComponent<LineRenderer>();
        line_render.SetPosition(0, Cube.position);
        line_render.SetPosition(1, Sphere.position);
        

	}
}
