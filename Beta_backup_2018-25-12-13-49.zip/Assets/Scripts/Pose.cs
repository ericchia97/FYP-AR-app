﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class Pose : MonoBehaviour {

    public Text pos1_x;
    public Text pos1_y;
    public Text pos1_z;
    public int unit;
    public Vector3 pos;
	// Use this for initialization
	void Start () {
        unit = 0;
    }
	
	// Update is called once per frame
	void Update () {
        
        pos = transform.position;
        pos1_x.text = "pos1_x:" + pos.x.ToString();
        pos1_y.text = "pos1_y:" + pos.y.ToString();
        pos1_z.text = "pos1_z:" + pos.z.ToString();
        
    }

 

    
}

//unit is a flag of changing the units, the following numbers will
//be a trigger to change the curent unit.
// 0 = default,
// 1 = cm to m, 2 = inch to m, 
// 3 = cm to inch, 4 = m to inch,
// 5 = m to cm, 6 = inch to cm