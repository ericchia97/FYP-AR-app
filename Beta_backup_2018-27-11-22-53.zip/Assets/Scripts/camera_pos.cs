﻿using System.Collections;
using UnityEngine.UI;
using UnityEngine;

public class camera_pos : MonoBehaviour {

    public Text cam_x;
    public Text cam_y;
    public Text cam_z;
    public Vector3 cam_pos;
    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        cam_pos = transform.position;
        cam_x.text = "cam_x:" + cam_pos.x.ToString();
        cam_y.text = "cam_y:" + cam_pos.y.ToString();
        cam_z.text = "cam_z:" + cam_pos.z.ToString();
    }
}
