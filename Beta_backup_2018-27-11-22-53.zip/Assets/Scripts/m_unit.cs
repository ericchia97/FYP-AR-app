﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class m_unit : MonoBehaviour
{
    public Distance_text dis_txt;
    public Text m_dis_txt;

    public void SetText(string text)
    {
        Text txt = transform.Find("Text").GetComponent<Text>();
        txt.text = text;
    }

    void Start()
    {
        GameObject transform_m = GameObject.Find("Distance");
        Distance_text distance_m = transform_m.GetComponent<Distance_text>();
       
       // gameObject.SendMessage("unit_m");
        
    }

    public void meter(float unit_m)
    {
        
        m_dis_txt.text = "Distance:" + unit_m.ToString();
    }
}
