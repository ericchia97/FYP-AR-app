﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class Distance_text : MonoBehaviour
{

    public GameObject GamePose1, GamePose2;
    public GameObject LengthX;
    public Vector3 position2, position1;
    public Text distance;
    public float total_Distance;
    public float unit_m;
    Vector3 pos_tempX;

   
    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
     
        pos_tempX = transform.position;
        position1 = GamePose1.GetComponent<Pose>().pos;
        position2 = GamePose2.GetComponent<Pose2>().pos2;

        float distanceX = position2.x - position1.x;
        float distanceY = position1.y - position2.y;
        float distanceZ = position1.z - position2.z;
        total_Distance = Mathf.Sqrt(distanceX * distanceX + distanceY * distanceY + distanceZ * distanceZ);

        unit_m = total_Distance / 100;
        //distance = Mathf.RoundToInt(distance);
        GetComponent<TextMesh>().text = total_Distance.ToString("f1");

        
        distance.text = "Distance:" + total_Distance.ToString();

    }


}
