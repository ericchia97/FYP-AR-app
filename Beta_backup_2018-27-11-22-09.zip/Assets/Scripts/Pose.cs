﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class Pose : MonoBehaviour {

    public Text pos1_x;
    public Text pos1_y;
    public Text pos1_z;
    public Vector3 pos;
	// Use this for initialization
	void Start () {
       
	}
	
	// Update is called once per frame
	void Update () {
		
        pos = transform.position;
        pos1_x.text = "pos1_x:" + pos.x.ToString();
        pos1_y.text = "pos1_y:" + pos.y.ToString();
        pos1_z.text = "pos1_z:" + pos.z.ToString();
        

    }
}
